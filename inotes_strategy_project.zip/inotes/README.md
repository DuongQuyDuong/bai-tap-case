# iNotes — Strategy Pattern (JSP/Servlet, Java 17, MySQL / TXT)

## Chạy dự án

1. Cài Java 17+, Maven, Tomcat 10.1+ và MySQL 8 (nếu dùng MySQL).
2. Chạy `database.sql` trong MySQL để tạo CSDL `inotes_db` và danh mục.
3. Nếu dùng MySQL, đặt biến môi trường `INOTES_DB_USER`, `INOTES_DB_PASSWORD`, tùy chọn `INOTES_DB_URL`.
4. Tùy chọn đặt `INOTES_FILE_PATH` cho đường dẫn file TXT. Mặc định ở `~/inotes-data/notes.txt`, **không nằm trong webapp**, tránh mất dữ liệu khi redeploy.
5. Tại thư mục dự án chạy `mvn clean package`, triển khai `target/inotes.war` lên Tomcat.
6. Truy cập `http://localhost:8080/inotes/notes`.

## Các tính năng

- Thêm, xem, sửa, xóa, liệt kê và tìm ghi chú theo tiêu đề hoặc nội dung.
- Ba phân loại cố định: Cá nhân (1), Công việc (2), Học tập (3), tương ứng với bảng `note_type`.
- Dropdown chuyển Strategy cho từng phiên HTTP: file TXT (mặc định) hoặc MySQL; **không tự đồng bộ dữ liệu giữa hai nguồn**.
- `NoteManagement` giữ `NoteStrategy`, thay bằng `setStrategy()`, giao diện không phụ thuộc SQL/file.
- Định dạng file `id|title|content|typeId`, escape ký tự `|`, `\` và xuống dòng.
- Dữ liệu MySQL giữ qua restart; dữ liệu file nằm ở đường dẫn cấu hình.

## Lưu ý

Bản thực hành không có đăng nhập/CSRF; **chỉ dùng local để học**, không đưa lên Internet công khai. Muốn thêm phân loại mới cần đồng bộ bảng SQL và danh sách tại controller. Không có migration giữa hai nguồn.
