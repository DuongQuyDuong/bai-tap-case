<% response.sendRedirect(request.getContextPath()+"/notes"); %>
