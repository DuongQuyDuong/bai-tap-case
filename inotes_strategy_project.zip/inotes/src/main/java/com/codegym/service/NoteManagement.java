package com.codegym.service;
import com.codegym.model.Note;
import com.codegym.strategy.NoteStrategy;
import java.util.List;

/** Context Strategy Pattern: thay nguồn dữ liệu runtime mà không đổi nghiệp vụ. */
public class NoteManagement {
    private NoteStrategy strategy;
    public NoteManagement(NoteStrategy strategy){setStrategy(strategy);}
    public void setStrategy(NoteStrategy strategy){if(strategy==null)throw new IllegalArgumentException("strategy");this.strategy=strategy;}
    public List<Note> searchNotes(String keyword) throws Exception {return keyword==null||keyword.isBlank()?strategy.findAll():strategy.search(keyword.trim());}
    public void addNote(String title,String content,int typeId) throws Exception {strategy.save(new Note(0,title,content,typeId));}
    public void save(Note note) throws Exception {strategy.save(note);}
    public void deleteNote(int id) throws Exception {strategy.delete(id);}
    public Note getNote(int id) throws Exception {return strategy.findById(id);}
}
