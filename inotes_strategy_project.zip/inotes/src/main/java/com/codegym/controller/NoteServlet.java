package com.codegym.controller;
import com.codegym.model.Note;
import com.codegym.service.NoteManagement;
import com.codegym.strategy.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.nio.file.Paths;

/** GET: danh sách, xem, sửa, tạo. POST: lưu, xóa, chuyển Strategy. */
@WebServlet("/notes")
public class NoteServlet extends HttpServlet {
    private final NoteFileStrategy fileStrategy=new NoteFileStrategy(Paths.get(System.getenv().getOrDefault("INOTES_FILE_PATH",System.getProperty("user.home")+"/inotes-data/notes.txt")));
    private final NoteDBStrategy dbStrategy=new NoteDBStrategy();
    private static final String[] TYPES={"", "Cá nhân", "Công việc", "Học tập"};
    private NoteManagement management(HttpServletRequest req){
        String mode=(String)req.getSession().getAttribute("mode");
        return new NoteManagement("mysql".equals(mode)?dbStrategy:fileStrategy);
    }
    private int id(HttpServletRequest req){return Integer.parseInt(req.getParameter("id"));}
    private void show(HttpServletRequest req,HttpServletResponse resp,String view) throws ServletException,IOException {
        req.setAttribute("types",TYPES);
        req.getRequestDispatcher("/WEB-INF/views/"+view+".jsp").forward(req,resp);
    }
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");NoteManagement m=management(req);
        try {
            String action=req.getParameter("action");
            if("new".equals(action)){show(req,resp,"form");return;}
            if("edit".equals(action)||"view".equals(action)) {
                Note note=m.getNote(id(req));if(note==null){resp.sendError(404,"Không tìm thấy ghi chú");return;}
                req.setAttribute("note",note);show(req,resp,"edit".equals(action)?"form":"view");return;
            }
            String keyword=req.getParameter("q");req.setAttribute("notes",m.searchNotes(keyword));req.setAttribute("keyword",keyword==null?"":keyword);
            show(req,resp,"list");
        }catch(NumberFormatException e){resp.sendError(400,"ID không hợp lệ");}
        catch(Exception e){getServletContext().log("Lỗi đọc ghi chú",e);req.setAttribute("error",e.getMessage());show(req,resp,"list");}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");String action=req.getParameter("action");
        if("storage".equals(action)) {
            String mode=req.getParameter("mode");
            if(!"file".equals(mode)&&!"mysql".equals(mode)){resp.sendError(400);return;}
            req.getSession().setAttribute("mode",mode);resp.sendRedirect(req.getContextPath()+"/notes");return;
        }
        NoteManagement m=management(req);
        try {
            if("delete".equals(action))m.deleteNote(id(req));
            else if("save".equals(action)) {
                String title=req.getParameter("title"),content=req.getParameter("content");int typeId=Integer.parseInt(req.getParameter("typeId"));
                if(title==null||title.isBlank()||title.length()>255||typeId<1||typeId>3)throw new IllegalArgumentException("Tiêu đề hoặc phân loại không hợp lệ");
                String rawId=req.getParameter("id");int noteId=rawId==null||rawId.isBlank()?0:Integer.parseInt(rawId);
                m.save(new Note(noteId,title.trim(),content==null?"":content,typeId));
            }else {resp.sendError(400);return;}
            resp.sendRedirect(req.getContextPath()+"/notes");
        }catch(Exception e){getServletContext().log("Lỗi lưu ghi chú",e);req.setAttribute("error",e.getMessage());
            if("save".equals(action)){req.setAttribute("note",new Note(0,req.getParameter("title"),req.getParameter("content"),1));show(req,resp,"form");}
            else show(req,resp,"list");}
    }
}
