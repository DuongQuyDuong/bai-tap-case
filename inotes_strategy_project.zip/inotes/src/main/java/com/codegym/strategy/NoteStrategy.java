package com.codegym.strategy;
import com.codegym.model.Note;
import java.util.List;

/** Strategy: hợp đồng thống nhất cho lưu trữ MySQL và file. */
public interface NoteStrategy {
    void save(Note note) throws Exception;
    void delete(int id) throws Exception;
    List<Note> findAll() throws Exception;
    List<Note> search(String keyword) throws Exception;
    Note findById(int id) throws Exception;
}
