package com.codegym.strategy;

import com.codegym.model.Note;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/** Concrete Strategy: file UTF-8; 4 cột id|title|content|typeId, escape dấu phân cách và xuống dòng. */
public class NoteFileStrategy implements NoteStrategy {
    private final Path path;
    public NoteFileStrategy(Path path) {this.path=path.toAbsolutePath();}
    private static String escape(String s) {
        return (s==null?"":s).replace("\\","\\\\").replace("|","\\|").replace("\r","\\r").replace("\n","\\n");
    }
    private static List<String> splitEscaped(String line) {
        List<String> fields=new ArrayList<>();StringBuilder b=new StringBuilder();boolean escaped=false;
        for(char c:line.toCharArray()) {
            if(escaped) {if(c=='n')b.append('\n');else if(c=='r')b.append('\r');else b.append(c);escaped=false;}
            else if(c=='\\') escaped=true;
            else if(c=='|'){fields.add(b.toString());b.setLength(0);}else b.append(c);
        }
        if(escaped)b.append('\\'); fields.add(b.toString());return fields;
    }
    private List<Note> load() throws IOException {
        if(!Files.exists(path))return new ArrayList<>();List<Note> notes=new ArrayList<>();
        for(String line:Files.readAllLines(path,StandardCharsets.UTF_8)) {
            if(line.isBlank()) continue;List<String> f=splitEscaped(line);
            if(f.size()!=4)throw new IOException("Dòng dữ liệu file không hợp lệ");
            try {notes.add(new Note(Integer.parseInt(f.get(0)),f.get(1),f.get(2),Integer.parseInt(f.get(3))));}
            catch(NumberFormatException ex){throw new IOException("ID/typeId không hợp lệ",ex);}
        }
        return notes;
    }
    private void write(List<Note> notes) throws IOException {
        Path parent=path.getParent();if(parent!=null)Files.createDirectories(parent);
        List<String> lines=new ArrayList<>();for(Note n:notes)lines.add(n.getId()+"|"+escape(n.getTitle())+"|"+escape(n.getContent())+"|"+n.getTypeId());
        Path tmp=Files.createTempFile(parent,"inotes-",".tmp");
        try {Files.write(tmp,lines,StandardCharsets.UTF_8);try {Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING);}}
        finally {Files.deleteIfExists(tmp);}
    }
    @Override public synchronized void save(Note note) throws Exception {
        List<Note> notes=load();if(note.getId()==0){int next=notes.stream().mapToInt(Note::getId).max().orElse(0)+1;note.setId(next);notes.add(note);}
        else {int idx=-1;for(int i=0;i<notes.size();i++)if(notes.get(i).getId()==note.getId()){idx=i;break;}
            if(idx<0)throw new IOException("Không tìm thấy ghi chú để cập nhật");notes.set(idx,note);}
        write(notes);
    }
    @Override public synchronized void delete(int id) throws Exception {List<Note> notes=load();notes.removeIf(n->n.getId()==id);write(notes);}
    @Override public synchronized List<Note> findAll() throws Exception {List<Note> notes=load();Collections.reverse(notes);return notes;}
    @Override public synchronized List<Note> search(String keyword) throws Exception {
        String k=keyword.toLowerCase(Locale.ROOT);
        return findAll().stream().filter(n->n.getTitle().toLowerCase(Locale.ROOT).contains(k)||(n.getContent()!=null&&n.getContent().toLowerCase(Locale.ROOT).contains(k))).collect(Collectors.toList());
    }
    @Override public synchronized Note findById(int id) throws Exception {for(Note n:load())if(n.getId()==id)return n;return null;}
}
