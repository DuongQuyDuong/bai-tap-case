package com.codegym.strategy;

import com.codegym.model.Note;
import java.sql.*;
import java.util.*;

/** Concrete Strategy: MySQL qua JDBC PreparedStatement. */
public class NoteDBStrategy implements NoteStrategy {
    private Connection open() throws SQLException {
        String url=System.getenv().getOrDefault("INOTES_DB_URL","jdbc:mysql://localhost:3306/inotes_db?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Ho_Chi_Minh");
        String user=System.getenv().getOrDefault("INOTES_DB_USER","root");
        String pass=System.getenv().getOrDefault("INOTES_DB_PASSWORD","");
        return DriverManager.getConnection(url,user,pass);
    }
    private Note from(ResultSet rs) throws SQLException {
        return new Note(rs.getInt("id"),rs.getString("title"),rs.getString("content"),rs.getInt("type_id"));
    }
    @Override public void save(Note note) throws Exception {
        String sql=note.getId()==0 ? "INSERT INTO notes(title,content,type_id) VALUES(?,?,?)" : "UPDATE notes SET title=?,content=?,type_id=? WHERE id=?";
        try(Connection c=open();PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1,note.getTitle());ps.setString(2,note.getContent());ps.setInt(3,note.getTypeId());
            if(note.getId()!=0) ps.setInt(4,note.getId());
            if(ps.executeUpdate()==0) throw new SQLException("Không tìm thấy ghi chú để cập nhật");
            if(note.getId()==0) try(ResultSet keys=ps.getGeneratedKeys()) {if(keys.next()) note.setId(keys.getInt(1));}
        }
    }
    @Override public void delete(int id) throws Exception {
        try(Connection c=open();PreparedStatement ps=c.prepareStatement("DELETE FROM notes WHERE id=?")) {ps.setInt(1,id);ps.executeUpdate();}
    }
    @Override public List<Note> findAll() throws Exception {return query("SELECT id,title,content,type_id FROM notes ORDER BY id DESC",null);}
    @Override public List<Note> search(String keyword) throws Exception {
        return query("SELECT id,title,content,type_id FROM notes WHERE LOWER(title) LIKE ? OR LOWER(content) LIKE ? ORDER BY id DESC",keyword);
    }
    private List<Note> query(String sql,String keyword) throws Exception {
        List<Note> result=new ArrayList<>();
        try(Connection c=open(); PreparedStatement ps=c.prepareStatement(sql)) {
            if(keyword!=null) {String k="%"+keyword.toLowerCase(Locale.ROOT)+"%";ps.setString(1,k);ps.setString(2,k);}
            try(ResultSet rs=ps.executeQuery()){while(rs.next())result.add(from(rs));}
        }
        return result;
    }
    @Override public Note findById(int id) throws Exception {
        try(Connection c=open();PreparedStatement ps=c.prepareStatement("SELECT id,title,content,type_id FROM notes WHERE id=?")) {
            ps.setInt(1,id);try(ResultSet rs=ps.executeQuery()){return rs.next()?from(rs):null;}
        }
    }
}
